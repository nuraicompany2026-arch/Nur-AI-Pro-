const keyInput = document.getElementById("key");
const commandInput = document.getElementById("command");
const result = document.getElementById("result");
document.getElementById("run").addEventListener("click", async () => {
  result.textContent = "Орындалып жатыр…";
  try {
    const response = await fetch("/admin/command", {
      method: "POST", headers: { "Content-Type": "application/json", "x-admin-key": keyInput.value },
      body: JSON.stringify({ command: commandInput.value })
    });
    const data = await response.json();
    result.textContent = data.message || "Нәтиже жоқ.";
  } catch { result.textContent = "Сервермен байланыс жоқ."; }
});
