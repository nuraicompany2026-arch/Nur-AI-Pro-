function calculate(input) {
  const match = String(input || "").replace(",", ".").match(/(-?\d+(?:\.\d+)?)\s*([+\-*/])\s*(-?\d+(?:\.\d+)?)/);
  if (!match) return null;
  const a = Number(match[1]), b = Number(match[3]), op = match[2];
  if (op === "/" && b === 0) return "Нөлге бөлуге болмайды.";
  const result = op === "+" ? a + b : op === "-" ? a - b : op === "*" ? a * b : a / b;
  return `Жауабы: ${Number(result.toPrecision(12))}`;
}
module.exports = { calculate };
