function answerSystem(text) {
  const t = String(text || "").toLowerCase();
  if (/уақыт|сағат қанша/.test(t)) return `Құрылғы уақыты: ${new Date().toLocaleString("kk-KZ")}.`;
  if (/нұсқа|версия|version/.test(t)) return "NUR AI PRO 2.0";
  return null;
}
module.exports = { answerSystem };
