# NUR AI PRO 2.0

API-сіз жергілікті көмекші. Бұл нұсқа ережелерге, шағын білім базасына және калькуляторға сүйенеді; үлкен тілдік модель емес және өздігінен интернетке қосылмайды.

## Іске қосу
1. Node.js орнатылған ортада осы бумаға кіріңіз.
2. `npm install`
3. Әкімші панелі қажет болса, `NUR_ADMIN_KEY` орта айнымалысын орнатыңыз.
4. `npm start`
5. Браузерде `http://localhost:3000` ашыңыз.

## API
- `GET /status`
- `POST /api/chat` — `{ "message": "...", "userId": "nursultan" }`
- `POST /memory/save` — `{ "userId": "nursultan", "text": "..." }`
- `GET /memory/:userId`
- `DELETE /memory/:userId`
- `POST /admin/command` — `x-admin-key` тақырыбы қажет.

## Әкімші командалары
`status`, `help`, `maintenance-on`, `maintenance-off`, `title ЖАҢА АТАУ`, `announce Хабарлама`.

Ескерту: әкімші кілтін кодқа жазбаңыз және ашық репозиторийге жарияламаңыз. Бұл бастапқы нұсқа; интернетке жарияламас бұрын аутентификацияны, rate limit және деректерді қорғауды күшейту керек.
