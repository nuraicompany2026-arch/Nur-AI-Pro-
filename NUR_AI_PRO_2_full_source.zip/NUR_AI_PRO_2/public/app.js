const messages = document.getElementById("messages");
const form = document.getElementById("chatForm");
const input = document.getElementById("message");
const statusEl = document.getElementById("status");
const userId = localStorage.getItem("nur_user_id") || "nursultan";
localStorage.setItem("nur_user_id", userId);

function addMessage(text, who) {
  const el = document.createElement("div");
  el.className = `msg ${who}`;
  el.textContent = text;
  messages.appendChild(el);
  messages.scrollTop = messages.scrollHeight;
}
addMessage("Сәлем! Мен NUR AI PRO. Сұрағыңды жаза бер.", "bot");
form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const message = input.value.trim();
  if (!message) return;
  addMessage(message, "user");
  input.value = "";
  statusEl.textContent = "Жауап дайындалып жатыр…";
  try {
    const response = await fetch("/api/chat", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message, userId })
    });
    const data = await response.json();
    addMessage(data.reply || data.message || "Жауап алынбады.", "bot");
    statusEl.textContent = "Байланыс бар";
  } catch {
    addMessage("Серверге қосыла алмадым. Сервердің іске қосылғанын тексер.", "bot");
    statusEl.textContent = "Байланыс жоқ";
  }
});
