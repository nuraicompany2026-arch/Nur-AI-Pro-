const { calculate } = require("../modules/calculator");
const { answerKnowledge } = require("../modules/knowledge");
const { answerAssistant } = require("../modules/assistant");
const { answerSystem } = require("../modules/system");

async function handleChat(message, context = {}) {
  const text = String(message || "").trim();
  const calc = calculate(text);
  if (calc !== null) return { reply: calc, module: "calculator" };

  const system = answerSystem(text);
  if (system) return { reply: system, module: "system" };

  const assistant = answerAssistant(text, context);
  if (assistant) return { reply: assistant, module: "assistant" };

  const knowledge = answerKnowledge(text);
  if (knowledge) return { reply: knowledge, module: "knowledge" };

  const recent = (context.history || []).slice(-4).map(x => x.text).filter(Boolean);
  if (/сәлем|салем|hello|привет/i.test(text)) {
    return { reply: "Сәлем! Мен NUR AI PRO жүйесімін. Не жөнінде көмектесейін?", module: "chat" };
  }
  if (/атың кім|есімің кім|who are you/i.test(text)) {
    return { reply: "Мен — NUR AI PRO. API қолданбайтын жергілікті көмекші ядромын.", module: "chat" };
  }
  if (/рахмет|спасибо|thank/i.test(text)) {
    return { reply: "Әрқашан көмектесуге дайынмын! Тағы сұрағың болса, жаза бер.", module: "chat" };
  }
  return {
    reply: "Сұрағыңды түсіндім деп ойлаймын, бірақ менің API-сіз білім базам шектеулі. Нақтырақ жазып көр немесе «көмек» деп жаз. Мен өздігінен интернетке қосылмаймын.",
    module: "chat"
  };
}
module.exports = { handleChat };
