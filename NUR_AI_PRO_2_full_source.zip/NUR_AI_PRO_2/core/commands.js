const state = { maintenance: false, announcement: "", siteName: "NUR AI PRO" };
function run(command) {
  const c = String(command || "").trim();
  if (c === "status") return { success: true, message: "Жүйе жұмыс істеп тұр.", state: { ...state } };
  if (c === "maintenance-on") { state.maintenance = true; return { success: true, message: "Техникалық қызмет көрсету режимі қосылды." }; }
  if (c === "maintenance-off") { state.maintenance = false; return { success: true, message: "Техникалық қызмет көрсету режимі өшірілді." }; }
  if (c.startsWith("title ")) { state.siteName = c.slice(6, 80) || "NUR AI PRO"; return { success: true, message: `Сайт атауы: ${state.siteName}` }; }
  if (c.startsWith("announce ")) { state.announcement = c.slice(9, 250); return { success: true, message: "Хабарландыру сақталды." }; }
  if (c === "help") return { success: true, message: "Командалар: status, maintenance-on, maintenance-off, title АТАУ, announce МӘТІН" };
  return { success: false, message: "Белгісіз команда. help деп жазыңыз." };
}
module.exports = { run, state };
