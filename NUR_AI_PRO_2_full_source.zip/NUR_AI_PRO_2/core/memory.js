const fs = require("fs");
const path = require("path");
const dir = path.join(__dirname, "..", "database");
const file = path.join(dir, "memory.json");
if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
if (!fs.existsSync(file)) fs.writeFileSync(file, "{}\n", "utf8");

function readAll() {
  try { return JSON.parse(fs.readFileSync(file, "utf8") || "{}"); }
  catch { return {}; }
}
function writeAll(data) {
  const temp = file + ".tmp";
  fs.writeFileSync(temp, JSON.stringify(data, null, 2), "utf8");
  fs.renameSync(temp, file);
}
function save(userId, item) {
  const data = readAll();
  if (!Array.isArray(data[userId])) data[userId] = [];
  data[userId].push({ role: item.role || "note", text: String(item.text || "").slice(0, 1000), at: new Date().toISOString() });
  data[userId] = data[userId].slice(-100);
  writeAll(data);
  return true;
}
function recall(userId) { return readAll()[userId] || []; }
function clear(userId) { const data = readAll(); delete data[userId]; writeAll(data); }
module.exports = { save, recall, clear };
