const express = require("express");
const path = require("path");
const fs = require("fs");
const app = express();
const PORT = process.env.PORT || 3000;

const { handleChat } = require("./core/brain");
const memory = require("./core/memory");
const commands = require("./core/commands");
const { safeText, validUserId, adminKeyOk } = require("./core/security");

app.disable("x-powered-by");
app.use(express.json({ limit: "32kb" }));
app.use(express.static(path.join(__dirname, "public")));
app.use(express.static(__dirname));

app.get("/status", (_req, res) => {
  res.json({ status: "connected", name: "NUR AI PRO", version: "2.0.0", api: "not_required" });
});

app.post("/api/chat", async (req, res) => {
  try {
    const message = safeText(req.body && req.body.message, 2000);
    const userId = validUserId(req.body && req.body.userId) || "guest";
    if (!message) return res.status(400).json({ success: false, message: "Хабарлама бос болмауы керек." });
    const history = memory.recall(userId);
    const result = await handleChat(message, { userId, history });
    memory.save(userId, { role: "user", text: message });
    memory.save(userId, { role: "assistant", text: result.reply });
    res.json({ success: true, reply: result.reply, module: result.module });
  } catch (error) {
    console.error("CHAT_ERROR", error.message);
    res.status(500).json({ success: false, message: "Ішкі қате. Қайта көріңіз." });
  }
});

app.post("/memory/save", (req, res) => {
  const userId = validUserId(req.body && req.body.userId);
  const text = safeText(req.body && req.body.text, 1000);
  if (!userId || !text) return res.status(400).json({ success: false, message: "userId және text қажет." });
  res.json({ success: memory.save(userId, { role: "note", text }) });
});
app.get("/memory/:userId", (req, res) => {
  const userId = validUserId(req.params.userId);
  if (!userId) return res.status(400).json({ success: false });
  res.json({ success: true, memory: memory.recall(userId) });
});
app.delete("/memory/:userId", (req, res) => {
  const userId = validUserId(req.params.userId);
  if (!userId) return res.status(400).json({ success: false });
  memory.clear(userId);
  res.json({ success: true, message: "Жад тазартылды." });
});

app.post("/admin/command", (req, res) => {
  const key = req.headers["x-admin-key"] || (req.body && req.body.adminKey);
  if (!adminKeyOk(key)) return res.status(403).json({ success: false, message: "Әкімші кілті қате." });
  const command = safeText(req.body && req.body.command, 300);
  const result = commands.run(command);
  res.json(result);
});

app.get("/admin/status", (req, res) => {
  const key = req.headers["x-admin-key"];
  if (!adminKeyOk(key)) return res.status(403).json({ success: false });
  res.json({ success: true, status: "online", name: "NUR AI PRO", uptime: Math.floor(process.uptime()) });
});

app.get("/", (_req, res) => res.sendFile(path.join(__dirname, "index.html")));
app.get("/admin", (_req, res) => res.sendFile(path.join(__dirname, "admin.html")));

app.listen(PORT, "0.0.0.0", () => console.log(`NUR AI PRO іске қосылды: http://localhost:${PORT}`));
